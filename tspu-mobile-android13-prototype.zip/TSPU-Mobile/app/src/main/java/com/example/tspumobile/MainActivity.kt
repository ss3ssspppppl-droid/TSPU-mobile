package com.example.tspumobile

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.view.ViewGroup
import android.graphics.Color
import android.graphics.Typeface
import android.content.Context

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var domains: EditText
    private val prefs by lazy { getSharedPreferences("tspu", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            setBackgroundColor(Color.rgb(15, 17, 24))
        }
        fun label(text: String, size: Float, color: Int, bold: Boolean = false) =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(color)
                if (bold) setTypeface(null, Typeface.BOLD)
            }
        layout.addView(label("TSPU MOBILE", 26f, Color.WHITE, true))
        layout.addView(label("Локальный DNS-фильтр · версия 0.1.0", 14f, 0xFFB7B9C5.toInt()))
        status = label("Статус: остановлен", 17f, 0xFFB7B9C5.toInt(), true)
        val statusParams = LinearLayout.LayoutParams(-1, -2)
        statusParams.topMargin = pad
        layout.addView(status, statusParams)

        layout.addView(label("Блокируемые домены (по одному на строку)", 14f, Color.WHITE, true))
        domains = EditText(this).apply {
            setTextColor(Color.WHITE)
            setHintTextColor(0xFF888A95.toInt())
            setHint("example.com\nads.example.org")
            setText(prefs.getString("blocked", ""))
            minLines = 5
            setBackgroundColor(0xFF242735.toInt())
            setPadding(pad / 2, pad / 2, pad / 2, pad / 2)
        }
        layout.addView(domains, LinearLayout.LayoutParams(-1, -2))
        val save = Button(this).apply {
            text = "Сохранить правила"
            setOnClickListener {
                prefs.edit().putString("blocked", domains.text.toString()).apply()
                status.text = "Правила сохранены"
            }
        }
        layout.addView(save)
        val start = Button(this).apply {
            text = "Запустить фильтр"
            setOnClickListener {
                val prep = VpnService.prepare(this@MainActivity)
                if (prep != null) startActivityForResult(prep, 100)
                else startFilter()
            }
        }
        layout.addView(start)
        val stop = Button(this).apply {
            text = "Остановить фильтр"
            setOnClickListener {
                startService(Intent(this@MainActivity, DnsVpnService::class.java).setAction(DnsVpnService.ACTION_STOP))
                status.text = "Статус: остановлен"
            }
        }
        layout.addView(stop)
        val note = label(
            "Фильтр обрабатывает DNS-запросы только этого планшета. Он не расшифровывает HTTPS и пока не фильтрует устройства, подключённые к точке доступа.",
            13f, 0xFFB7B9C5.toInt()
        )
        val noteParams = LinearLayout.LayoutParams(-1, -2)
        noteParams.topMargin = pad
        layout.addView(note, noteParams)
        setContentView(layout)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == Activity.RESULT_OK) startFilter()
        else if (requestCode == 100) status.text = "Разрешение VPN не выдано"
    }

    private fun startFilter() {
        prefs.edit().putString("blocked", domains.text.toString()).apply()
        startForegroundService(Intent(this, DnsVpnService::class.java).setAction(DnsVpnService.ACTION_START))
        status.text = "Статус: запускается"
    }
}
