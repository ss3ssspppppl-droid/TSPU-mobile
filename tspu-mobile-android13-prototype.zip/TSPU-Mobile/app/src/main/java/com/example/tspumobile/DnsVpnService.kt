package com.example.tspumobile

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

class DnsVpnService : VpnService() {
    companion object {
        const val ACTION_START = "com.example.tspumobile.START"
        const val ACTION_STOP = "com.example.tspumobile.STOP"
        private const val CHANNEL = "tspu_filter"
        private const val NOTIFICATION_ID = 41
    }

    private var tun: ParcelFileDescriptor? = null
    private val running = AtomicBoolean(false)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopFilter()
            ACTION_START -> startFilter()
        }
        return START_NOT_STICKY
    }

    private fun startFilter() {
        if (running.get()) return
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        val descriptor = Builder()
            .setSession("TSPU Mobile DNS")
            .addAddress("10.77.0.1", 32)
            .addDnsServer("10.77.0.2")
            .addRoute("10.77.0.2", 32)
            .setMtu(1500)
            .establish()

        if (descriptor == null) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return
        }
        tun = descriptor
        running.set(true)
        thread(name = "tspu-dns-loop") { packetLoop(descriptor) }
    }

    private fun packetLoop(fd: ParcelFileDescriptor) {
        val input = FileInputStream(fd.fileDescriptor)
        val output = FileOutputStream(fd.fileDescriptor)
        val buffer = ByteArray(32767)
        try {
            while (running.get()) {
                val length = input.read(buffer)
                if (length <= 0) continue
                val packet = buffer.copyOf(length)
                val parsed = parseDnsUdp(packet) ?: continue
                val qname = readQName(parsed.dns, parsed.dnsOffset) ?: continue
                val blocked = getSharedPreferences("tspu", MODE_PRIVATE)
                    .getString("blocked", "").orEmpty()
                    .lines().map { it.trim().trimEnd('.').lowercase() }
                    .filter { it.isNotEmpty() }
                    .any { qname == it || qname.endsWith(".$it") }

                val dnsReply = if (blocked) makeNxDomain(parsed.dns, parsed.dnsOffset)
                              else queryUpstream(parsed.dns, parsed.dnsOffset)
                if (dnsReply != null) {
                    val replyPacket = makeIpv4UdpReply(packet, parsed, dnsReply)
                    if (replyPacket != null) output.write(replyPacket)
                }
            }
        } catch (_: Exception) {
        } finally {
            running.set(false)
        }
    }

    private data class Parsed(val ipHeaderLen: Int, val udpOffset: Int, val dnsOffset: Int, val srcPort: Int, val dstPort: Int)

    private fun parseDnsUdp(p: ByteArray): Parsed? {
        if (p.size < 28 || (p[0].toInt() ushr 4 and 0xF) != 4) return null
        val ihl = (p[0].toInt() and 0x0F) * 4
        if (ihl < 20 || p.size < ihl + 8 || (p[9].toInt() and 0xFF) != 17) return null
        val udp = ihl
        val src = u16(p, udp)
        val dst = u16(p, udp + 2)
        if (dst != 53) return null
        val dns = udp + 8
        if (p.size < dns + 12) return null
        return Parsed(ihl, udp, dns, src, dst)
    }

    private fun readQName(p: ByteArray, offset: Int): String? {
        if (offset + 12 >= p.size) return null
        var i = offset + 12
        val labels = mutableListOf<String>()
        while (i < p.size) {
            val n = p[i++].toInt() and 0xFF
            if (n == 0) break
            if (n > 63 || i + n > p.size) return null
            labels.add(String(p, i, n, Charsets.US_ASCII))
            i += n
            if (labels.size > 30) return null
        }
        return labels.joinToString(".").lowercase().takeIf { it.isNotBlank() }
    }

    private fun makeNxDomain(packet: ByteArray, offset: Int): ByteArray {
        val dns = packet.copyOfRange(offset, packet.size)
        if (dns.size < 12) return dns
        dns[2] = 0x81.toByte()
        dns[3] = 0x83.toByte()
        for (i in 6..11) dns[i] = 0
        return dns
    }

    private fun queryUpstream(packet: ByteArray, offset: Int): ByteArray? {
        val query = packet.copyOfRange(offset, packet.size)
        return try {
            val socket = DatagramSocket()
            try {
                if (!protect(socket)) return null
                socket.soTimeout = 2500
                val address = InetAddress.getByName("1.1.1.1")
                socket.send(DatagramPacket(query, query.size, address, 53))
                val response = ByteArray(4096)
                val reply = DatagramPacket(response, response.size)
                socket.receive(reply)
                response.copyOf(reply.length)
            } finally {
                socket.close()
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun makeIpv4UdpReply(original: ByteArray, parsed: Parsed, dns: ByteArray): ByteArray? {
        val ipLen = parsed.ipHeaderLen
        val udpLen = 8 + dns.size
        val total = ipLen + udpLen
        if (total > 65535) return null
        val out = ByteArray(total)
        System.arraycopy(original, 0, out, 0, ipLen)
        // Swap IPv4 source and destination addresses.
        for (i in 0..3) {
            out[12 + i] = original[16 + i]
            out[16 + i] = original[12 + i]
        }
        out[2] = (total ushr 8).toByte(); out[3] = total.toByte()
        out[6] = 0; out[7] = 0
        out[10] = 0; out[11] = 0
        val udp = ipLen
        put16(out, udp, parsed.dstPort)
        put16(out, udp + 2, parsed.srcPort)
        put16(out, udp + 4, udpLen)
        put16(out, udp + 6, 0)
        System.arraycopy(dns, 0, out, udp + 8, dns.size)
        put16(out, 10, checksum(out, 0, ipLen))
        return out
    }

    private fun checksum(data: ByteArray, offset: Int, length: Int): Int {
        var sum = 0L
        var i = offset
        while (i + 1 < offset + length) {
            sum += (((data[i].toInt() and 0xFF) shl 8) or (data[i + 1].toInt() and 0xFF)).toLong()
            i += 2
        }
        if (i < offset + length) sum += ((data[i].toInt() and 0xFF) shl 8).toLong()
        while ((sum ushr 16) != 0L) sum = (sum and 0xFFFF) + (sum ushr 16)
        return sum.inv().toInt() and 0xFFFF
    }

    private fun u16(b: ByteArray, i: Int) = ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)
    private fun put16(b: ByteArray, i: Int, v: Int) { b[i] = (v ushr 8).toByte(); b[i + 1] = v.toByte() }

    private fun stopFilter() {
        running.set(false)
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "TSPU Mobile", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        )
        return if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL)
                .setContentTitle("TSPU Mobile активен")
                .setContentText("Локальная DNS-фильтрация включена")
                .setSmallIcon(android.R.drawable.stat_sys_warning)
                .setContentIntent(open).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("TSPU Mobile активен")
                .setContentText("Локальная DNS-фильтрация включена")
                .setSmallIcon(android.R.drawable.stat_sys_warning)
                .setContentIntent(open).build()
        }
    }

    override fun onDestroy() {
        stopFilter()
        super.onDestroy()
    }
}
